1. Setup a PostgreSQL database and put the connection URI in .env under DATABASE_URI

2. Run schema.sql on the database

3. Pick a password for the API and put it under API_KEY in .env

4. Setup a webhook for the Slack SOS channel and put it under SLACK_SOS_WEBHOOK in .env